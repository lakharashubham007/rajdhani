module.exports.Authorization = require('./authorization');
module.exports.Authentication = require('./auth');