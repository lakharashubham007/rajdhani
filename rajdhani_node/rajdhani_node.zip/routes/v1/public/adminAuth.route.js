// const express = require("express");
// const router = express.Router();
// const validate = require('../../middleware/validate')
// const authValidation = require("../../validation/auth.validation");
// const authController = require("../../controllers/auth.controller");
// const sidebarMenuController = require("../../controllers/sidebarMenu.controller");


// router.post("/login", validate(authValidation.login), authController.login);
// router.get("/sidebar-menus", sidebarMenuController.getSidebarMenus);

// router.get("/sidebar-menu", sidebarMenuController.getAllSidebarMenus);

// module.exports = router;








